<?php
  spl_autoload_register(function($class_name){
   include "../../classes/".$class_name.".php";
});

//error_reporting(0);

$notice = new Notice();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
     $msg = $notice->insertNotice($_POST);
}


?>



<?php include '../header.php';?>
  
   <!-- ########## START: MAIN PANEL ########## -->
  <div class="sl-mainpanel"> 
    <div class="sl-pagebody">
    <?php
        if (isset($msg)) {
           echo $msg;
          }
        ?>
        <div class="row row-sm">
          <div class="col-xl-12 mg-xl-t-0">
            <div class="card pd-20 pd-sm-40 form-layout form-layout-5"> 
              <div class="row">
                <div class="col-md-4">
                  <h6 class="tx-gray-800 tx-uppercase tx-bold tx-20 pb-3">Add Notice</h6>
                </div>
                <div class="col-md-8 view1">
                  <a class="btn btn-primary text-white" href="all-student.php">All Notice</a>
                </div>
              </div>
            
        <form class="pl-5 mt-4" action="" method="POST" enctype="multipart/form-data">
            <div class="row mb-3">
            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">তারিখ</h6></label>
            <span><h3 class="dot pt-2">:</h3></span>
            <div class="col-sm-9">
              <input type="date" class="form-control" id="date" name="date" placeholder="">
            </div>
            </div>

            <div class="row mb-3">
            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">বিষয় শিরোনাম</h6></label>
            <span><h3 class="dot pt-2">:</h3></span>
            <div class="col-sm-9">
              <input type="text" class="form-control" id="subject" name="subject" placeholder="">
            </div>
            </div>

            <div class="row mb-3">
            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">নোটিশ যুক্ত করুন</h6></label>
            <span><h3 class="dot">:</h3></span>
            <div class="col-sm-9">
              <input type="file" class="form-control" id="file" name="file" placeholder="">
            </div>
            </div>

             <div class="form-layout-footer mg-t-30 mg-r-75">
              <button type="submit" class="btn btn-info mg-r-5" name="submit" style="cursor: pointer;">Submit</button>
              <button class="btn btn-secondary" style="cursor: pointer;">Cancel</button>
              </div><!-- form-layout-footer -->
           </form>

            <div class="form-layout-footers mg-t-30">
              <a href="../index.php"><i class="fa fa-arrow-left back"> BACK</i></a>
              </div><!-- form-layout-footer -->
            </div><!-- card -->
          </div><!-- col-6 -->
        </div><!-- row -->
      </div><!-- sl-pagebody -->
    </div><!-- sl-mainpanel -->
    <!-- ########## END: MAIN PANEL ########## -->
  <?php include '../footer.php'; ?>
    