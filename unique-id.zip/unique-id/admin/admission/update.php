<?php
spl_autoload_register(function($class_name){
include "../../classes/".$class_name.".php";
});

//error_reporting(0);

$admission = new Admission();
?>

<?php
   if (isset($_GET['id'])) {
      $id = (int)$_GET['id'];
   $std = $admission->getAdmissionUpdateData($id);

  if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update'])) {
     $msg = $admission->updateAdmission($id, $_POST);
 }
}


?>


  <?php include '../header.php';?>

   <!-- ########## START: MAIN PANEL ########## -->
    <div class="sl-mainpanel">
      <div class="sl-pagebody">

        <?php
        if (isset($msg)) {
           echo $msg;
          }
        ?>

        <?Php 
          if (isset($_GET['error_msg'])) {
             $msg =   $_GET['error_msg'];
             echo $msg;
           }
        ?>

        <div class="row row-sm">
          <div class="col-xl-12 mg-t-25 mg-xl-t-0">
            <div class="card pd-20 pd-sm-40 form-layout form-layout-5">
              <div class="row">
                <div class="col-md-4">
                  <h6 class="tx-gray-800 tx-uppercase tx-bold tx-20 pb-5">Update Student</h6>
                </div>
                <div class="col-md-4"></div>
                <div class="col-md-4 tx-right view1">
                  <a href="all-student.php"><i class="fa fa-arrow-left back"> BACK</i></a>
                </div>
              </div>
            
          <form action="" method = "POST" enctype="multipart/form-data"> 
            <div class="row mb-3">
            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">ছাত্র/ছাত্রীর নাম</h6></label>
            <span><h3 class="text-black">:</h3></span>
            <div class="col-sm-9">
              <input type="text" class="form-control" id="name"   name="name" value="<?php echo $std['name']; ?>">
            </div>
            </div>

            <div class="row mb-3">
            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">পিতার নাম</h6></label>
            <span><h3 class="text-black">:</h3></span>
            <div class="col-sm-5">
              <input type="text" class="form-control" id="fname" name="fname" value="<?php echo $std['fname']; ?>">
            </div>

            <label for="inputEmail3" class="col-sm-1 col-form-label"><h6 class="text-black">ফোন</h6></label>
            <span><h3 class="text-black">:</h3></span>
            <div class="col-sm-3">
              <input type="text" class="form-control" id="phone1" name="phone1" value="<?php echo $std['phone1']; ?>">
            </div>
            </div>

           <div class="row mb-3">
            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">মাতার নাম</h6></label>
            <span><h3 class="text-black">:</h3></span>
            <div class="col-sm-5">
              <input type="text" class="form-control" id="mname" name="mname" value="<?php echo $std['mname']; ?>">
            </div>

            <label for="inputEmail3" class="col-sm-1 col-form-label"><h6 class="text-black">ফোন</h6></label>
            <span><h3 class="text-black">:</h3></span>
            <div class="col-sm-3">
              <input type="text" class="form-control" id="phone2" name="phone2" value="<?php echo $std['phone2']; ?>">
            </div>
            </div>
            
            <div class="row my-3 pl-3 tx-primary tx-bold">স্থায়ী ঠিকানা -</div>
            <div class="row mb-3">
            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black text-right">গ্রাম</h6></label>
            <span><h3 class="text-black">:</h3></span>
            <div class="col-sm-4">
              <input type="text" class="form-control" id="p_village" name="p_village" value="<?php echo $std['p_village']; ?>">
            </div>

            <label for="inputEmail3" class="col-sm-1 col-form-label"><h6 class="text-black">ডাকঘর</h6></label>
            <span><h3 class="text-black">:</h3></span>
            <div class="col-sm-4">
              <input type="text" class="form-control" id="p_post" name="p_post" value="<?php echo $std['p_post']; ?>">
            </div>
            </div>

            <div class="row mb-3">
            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black text-right">উপজেলা</h6></label>
            <span><h3 class="text-black">:</h3></span>
            <div class="col-sm-4">
              <input type="text" class="form-control" id="p_upazila" name="p_upazila" value="<?php echo $std['p_upazila']; ?>">
            </div>

            <label for="inputEmail3" class="col-sm-1 col-form-label"><h6 class="text-black">জেলা</h6></label>
            <span><h3 class="text-black">:</h3></span>
            <div class="col-sm-4">
              <input type="text" class="form-control" id="p_district" name="p_district" value="<?php echo $std['p_district']; ?>">
            </div>
            </div>

            <div class="row my-3 pl-3 tx-primary tx-bold">বর্তমান ঠিকানা -</div>
            <div class="row mb-3">
            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black text-right">গ্রাম</h6></label>
            <span><h3 class="text-black">:</h3></span>
            <div class="col-sm-4">
              <input type="text" class="form-control" id="c_village" name="c_village" value="<?php echo $std['c_village']; ?>">
            </div>

            <label for="inputEmail3" class="col-sm-1 col-form-label"><h6 class="text-black">ডাকঘর</h6></label>
            <span><h3 class="text-black">:</h3></span>
            <div class="col-sm-4">
              <input type="text" class="form-control" id="c_post" name="c_post" value="<?php echo $std['c_post']; ?>">
            </div>
            </div>

            <div class="row mb-3">
            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black text-right">উপজেলা</h6></label>
            <span><h3 class="text-black">:</h3></span>
            <div class="col-sm-4">
              <input type="text" class="form-control" id="c_upazila" name="c_upazila" value="<?php echo $std['c_upazila']; ?>">
            </div>

            <label for="inputEmail3" class="col-sm-1 col-form-label"><h6 class="text-black">জেলা</h6></label>
            <span><h3 class="text-black">:</h3></span>
            <div class="col-sm-4">
              <input type="text" class="form-control" id="c_district" name="c_district" value="<?php echo $std['c_district']; ?>">
            </div>
            </div>
            
            <div class="row mb-3">
            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">জন্ম তারিখ</h6></label>
            <span><h3 class="text-black">:</h3></span>
            <div class="col-sm-2">
              <input type="date" class="form-control" id="b_date" name="b_date" value="<?php echo $std['b_date']; ?>">
            </div>

            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">জন্ম নিবন্ধন নম্বর</h6></label>
            <span><h3 class="text-black">:</h3></span>
            <div class="col-sm-5">
              <input type="text" class="form-control" id="bid" name="bid" value="<?php echo $std['bid']; ?>">
            </div>
            </div>

            <div class="row mb-3">
            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">পিতার পেশা</h6></label>
            <span><h3 class="text-black">:</h3></span>
            <div class="col-sm-2">
              <input type="text" class="form-control" id="f_occupation" name="f_occupation" value="<?php echo $std['f_occupation']; ?>">
            </div>

            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">এন আইডি নম্বর</h6></label>
            <span><h3 class="text-black">:</h3></span>
            <div class="col-sm-5">
              <input type="text" class="form-control" id="f_nid" name="f_nid" value="<?php echo $std['f_nid']; ?>">
            </div>
            </div>


            <div class="row mb-3">
            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">মাতার পেশা</h6></label>
            <span><h3 class="text-black">:</h3></span>
            <div class="col-sm-2">
              <input type="text" class="form-control" id="m_occupation" name="m_occupation" value="<?php echo $std['m_occupation']; ?>">
            </div>

            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">এন আইডি নম্বর</h6></label>
            <span><h3 class="text-black">:</h3></span>
            <div class="col-sm-5">
              <input type="text" class="form-control" id="m_nid" name="m_nid" value="<?php echo $std['m_nid'];?>">
            </div>
            </div>

            <div class="row mb-3">
            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">ভর্তি ইচ্ছুক শ্রেনী</h6></label>
            <span><h3 class="text-black">:</h3></span>
            <div class="col-sm-4">
              <input type="text" class="form-control" id="admi_class" name="admi_class" value="<?php echo $std['admi_class'] ; ?>">
            </div>

            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">ভর্তি তারিখ</h6></label>
            <span><h3 class="text-black">:</h3></span>
            <div class="col-sm-3">
              <input type="date" class="form-control" id="admi_date" name="admi_date" value="<?php echo $std['admi_date']; ?>">
            </div>
            </div>

            <div class="row mb-3">
            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">ভর্তি রোল</h6></label>
            <span><h3 class="text-black">:</h3></span>
            <div class="col-sm-3">
              <input type="text" class="form-control" id="admi_roll" name="admi_roll" value="<?php echo $std['admi_roll']; ?>">
            </div>

            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">ইউনিক আইডি</h6></label>
            <span><h3 class="text-black">:</h3></span>
            <div class="col-sm-4">
              <input type="text" class="form-control" id="uniqid" name="uniqid" value="<?php echo $std['uniqid']; ?>">
            </div>
            </div>

            <div class="row mb-3">
            <label for="inputEmail3" class="col-sm-3 col-form-label"><h6 class="text-black">সর্বশেষ শিক্ষা প্রতিষ্ঠানের নাম</h6></label>
            <span><h3 class="text-black">:</h3></span>
            <div class="col-sm-8">
              <input type="text" class="form-control" id="last_ins_name" name="last_ins_name" value="<?php echo $std['last_ins_name']; ?>">
            </div>
            </div>

            <div class="row mb-3">
            <label for="inputEmail3" class="col-sm-3 col-form-label"><h6 class="text-black">ছবি যুক্ত করুন</h6></label>
            <span><h3 class="text-black">:</h3></span>
            <div class="col-sm-8">
              <input type="file" class="form-control" id="image" name="image">
              <img style="width: 50px; height: 50px;"; src="../uploads/image/<?php echo $std['image']; ?>">
            </div>
            </div>

             <div class="form-layout-footer mg-r-75 tx-right">
              <button type="submit" class="btn btn-info mg-r-15" name="update" style="cursor: pointer;">Update</button>
               <button class="btn btn-secondary" style="cursor: pointer;">Cancel</button>
              </div><!-- form-layout-footer -->
           </form>

            <div class="form-layout-footers mg-t-30">
              <!-- <a href="../index.php"><i class="fa fa-arrow-left back"> BACK</i></a> -->
              </div><!-- form-layout-footer -->
            </div><!-- card -->
          </div><!-- col-6 -->
        </div><!-- row -->
      </div><!-- sl-pagebody -->
    </div><!-- sl-mainpanel -->
    <!-- ########## END: MAIN PANEL ########## -->

   <?php include '../footer.php'; ?> 
