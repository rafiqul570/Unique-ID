<?php
  spl_autoload_register(function($class_name){
   include "../../classes/".$class_name.".php";
});

//error_reporting(0);

$admission = new Admission();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
     $msg = $admission->insertStudent($_POST);
}

//Session Start
 Session::init();
  if (! isset($_SESSION['login'])){
  header ('Location:../login.php');
  die();
  }

?>



<?php include '../header.php';?>
  
   <!-- ########## START: MAIN PANEL ########## -->
  <div class="sl-mainpanel"> 
    <div class="sl-pagebody">
    <?php
        if (isset($msg)) {
           echo $msg;
          }
        ?>
        <div class="row row-sm">
          <div class="col-xl-12 mg-xl-t-0">
            <div class="card pd-20 pd-sm-40 form-layout form-layout-5"> 
              <div class="row">
                <div class="col-md-4">
                  <h6 class="tx-gray-800 tx-uppercase tx-bold tx-20 pb-3">Add Student</h6>
                </div>
                <div class="col-md-8 tx-right view1">
                  <a class="btn btn-primary text-white" href="all-student.php">All Student</a>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12 tx-center">
                  <h2 class="tx-gray-1000 tx-uppercase tx-bold tx-20 pb-5 admi-form">Admission Form</h2>
                </div>
              </div>
            
          <form action="" method="POST" enctype="multipart/form-data"> 
            <div class="row mb-3">
            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">ছাত্র/ছাত্রীর নাম</h6></label>
            <span><h3 class="dot pt-2">:</h3></span>
            <div class="col-sm-9">
              <input type="text" class="form-control" id="name" name="name" placeholder="">
            </div>
            </div>

            <div class="row mb-3">
            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">পিতার নাম</h6></label>
            <span><h3 class="dot pt-2">:</h3></span>
            <div class="col-sm-5">
              <input type="text" class="form-control" id="fname" name="fname" placeholder="">
            </div>

            <label for="inputEmail3" class="col-sm-1 col-form-label phone"><h6 class="text-black">ফোন</h6></label>
            <span><h3 class="dot pt-2">:</h3></span>
            <div class="col-sm-3">
              <input type="text" class="form-control" id="phone1" name="phone1" placeholder="">
            </div>
            </div>

           <div class="row mb-3">
            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">মাতার নাম</h6></label>
            <span><h3 class="dot pt-2">:</h3></span>
            <div class="col-sm-5">
              <input type="text" class="form-control" id="mname" name="mname" placeholder="">
            </div>

            <label for="inputEmail3" class="col-sm-1 col-form-label phone"><h6 class="text-black">ফোন</h6></label>
            <span><h3 class="dot pt-2">:</h3></span>
            <div class="col-sm-3">
              <input type="text" class="form-control" id="phone2" name="phone2" placeholder="">
            </div>
            </div>
            
            <div class="row mb-3 pl-3">স্থায়ী ঠিকানা -</div>
            <div class="row mb-3">
            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black text-right">গ্রাম</h6></label>
            <span><h3 class="dot pt-2">:</h3></span>
            <div class="col-sm-4">
              <input type="text" class="form-control" id="p_village" name="p_village" placeholder="">
            </div>

            <label for="inputEmail3" class="col-sm-1 col-form-label phone"><h6 class="text-black">ডাকঘর</h6></label>
            <span><h3 class="dot pt-2">:</h3></span>
            <div class="col-sm-4">
              <input type="text" class="form-control" id="p_post" name="p_post" placeholder="">
            </div>
            </div>

            <div class="row mb-3">
            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black text-right">উপজেলা</h6></label>
            <span><h3 class="dot pt-2">:</h3></span>
            <div class="col-sm-4">
              <input type="text" class="form-control" id="p_upazila" name="p_upazila" placeholder="">
            </div>

            <label for="inputEmail3" class="col-sm-1 col-form-label phone"><h6 class="text-black">জেলা</h6></label>
            <span><h3 class="dot pt-2">:</h3></span>
            <div class="col-sm-4">
              <input type="text" class="form-control" id="p_district" name="p_district" placeholder="">
            </div>
            </div>

            <div class="row mb-3 pl-3">বর্তমান ঠিকানা -</div>
            <div class="row mb-3">
            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black text-right">গ্রাম</h6></label>
            <span><h3 class="dot pt-2">:</h3></span>
            <div class="col-sm-4">
              <input type="text" class="form-control" id="c_village" name="c_village" placeholder="">
            </div>

            <label for="inputEmail3" class="col-sm-1 col-form-label phone"><h6 class="text-black">ডাকঘর</h6></label>
            <span><h3 class="dot pt-2">:</h3></span>
            <div class="col-sm-4">
              <input type="text" class="form-control" id="c_post" name="c_post" placeholder="">
            </div>
            </div>

            <div class="row mb-3">
            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black text-right">উপজেলা</h6></label>
            <span><h3 class="dot pt-2">:</h3></span>
            <div class="col-sm-4">
              <input type="text" class="form-control" id="c_upazila" name="c_upazila" placeholder="">
            </div>

            <label for="inputEmail3" class="col-sm-1 col-form-label phone"><h6 class="text-black">জেলা</h6></label>
            <span><h3 class="dot pt-2">:</h3></span>
            <div class="col-sm-4">
              <input type="text" class="form-control" id="c_district" name="c_district" placeholder="">
            </div>
            </div>
            
            <div class="row mb-3">
            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">জন্ম তারিখ</h6></label>
            <span><h3 class="dot pt-2">:</h3></span>
            <div class="col-sm-3">
              <input type="date" class="form-control" id="b_date" name="b_date" placeholder="">
            </div>

            <label for="inputEmail3" class="col-sm-2 col-form-label phone"><h6 class="text-black">জন্ম নিবন্ধন নম্বর</h6></label>
            <span><h3 class="dot pt-2">:</h3></span>
            <div class="col-sm-4">
              <input type="text" class="form-control" id="bid" name="bid" placeholder="">
            </div>
            </div>

            <div class="row mb-3">
            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">পিতার পেশা</h6></label>
            <span><h3 class="dot pt-2">:</h3></span>
            <div class="col-sm-3">
              <input type="text" class="form-control" id="f_occupation" name="f_occupation" placeholder="">
            </div>

            <label for="inputEmail3" class="col-sm-2 col-form-label phone"><h6 class="text-black">এন আইডি নম্বর</h6></label>
            <span><h3 class="dot pt-2">:</h3></span>
            <div class="col-sm-4">
              <input type="text" class="form-control" id="f_nid" name="f_nid" placeholder="">
            </div>
            </div>


            <div class="row mb-3">
            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">মাতার পেশা</h6></label>
            <span><h3 class="dot pt-2">:</h3></span>
            <div class="col-sm-3">
              <input type="text" class="form-control" id="m_occupation" name="m_occupation" placeholder="">
            </div>

            <label for="inputEmail3" class="col-sm-2 col-form-label phone"><h6 class="text-black">এন আইডি নম্বর</h6></label>
            <span><h3 class="dot pt-2">:</h3></span>
            <div class="col-sm-4">
              <input type="text" class="form-control" id="m_nid" name="m_nid" placeholder="">
            </div>
            </div>

            <div class="row mb-3">
            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">ভর্তি ইচ্ছুক শ্রেনী</h6></label>
            <span><h3 class="dot pt-2">:</h3></span>
            <div class="col-sm-3">
              <input type="text" class="form-control" id="admi_class" name="admi_class" placeholder="">
            </div>

            <label for="inputEmail3" class="col-sm-2 col-form-label phone"><h6 class="text-black">ভর্তি তারিখ</h6></label>
            <span><h3 class="dot pt-2">:</h3></span>
            <div class="col-sm-4">
              <input type="date" class="form-control" id="admi_date" name="admi_date" placeholder="">
            </div>
            </div>

            <div class="row mb-3">
            <label for="inputEmail3" class="col-sm-2 col-form-label"><h6 class="text-black">ভর্তি রোল</h6></label>
            <span><h3 class="dot pt-2">:</h3></span>
            <div class="col-sm-3">
              <input type="text" class="form-control" id="admi_roll" name="admi_roll" placeholder="">
            </div>

            <label for="inputEmail3" class="col-sm-2 col-form-label phone"><h6 class="text-black">ইউনিক আইডি</h6></label>
            <span><h3 class="dot pt-2">:</h3></span>
            <div class="col-sm-4">
              <input type="text" class="form-control" id="uniqid" name="uniqid" placeholder="">
            </div>
            </div>

            <div class="row mb-3">
            <label for="inputEmail3" class="col-sm-3 col-form-label"><h6 class="text-black">সর্বশেষ শিক্ষা প্রতিষ্ঠানের নাম</h6></label>
            <span><h3 class="dot pt-2">:</h3></span>
            <div class="col-sm-8">
              <input type="text" class="form-control" id="last_ins_name" name="last_ins_name" placeholder="">
            </div>
            </div>

            <div class="row mb-3">
            <label for="inputEmail3" class="col-sm-4 col-form-label"><h6 class="text-black">যে শিক্ষা প্রতিষ্ঠানে ভর্তি হতে ইচ্ছুক</h6></label>
            <span><h3 class="dot pt-2">:</h3></span>
            <div class="col-sm-7">
              <select class="col-sm-12" name="ins_id">
                <option disabled selected>প্রতিষ্ঠান নির্বাচন করুন</option>
                <?php
                  $institution = new Institution();
                  $institution = $institution->getAllInstitutionData();
                    foreach ( $institution as $data) {     
                 ?>
                 <option value="<?php echo $data['id'];?>"><?php echo $data['ins_name']; ?> </option>
                 <?php
                 }
                ?>
              </select>
            </div>
            </div>

            <div class="row mb-3">
            <label for="inputEmail3" class="col-sm-3 col-form-label"><h6 class="text-black">ছবি যুক্ত করুন</h6></label>
            <span><h3 class="dot">:</h3></span>
            <div class="col-sm-8">
              <input type="file" class="form-control" id="image" name="image" placeholder="">
            </div>
            </div>

             <div class="form-layout-footer mg-t-30 mg-r-75 tx-right">
              <button type="submit" class="btn btn-info mg-r-5" name="submit" style="cursor: pointer;">Submit</button>
              <button class="btn btn-secondary" style="cursor: pointer;">Cancel</button>
              </div><!-- form-layout-footer -->
           </form>

            <div class="form-layout-footers mg-t-30">
              <a href="../index.php"><i class="fa fa-arrow-left back"> BACK</i></a>
              </div><!-- form-layout-footer -->
            </div><!-- card -->
          </div><!-- col-6 -->
        </div><!-- row -->
      </div><!-- sl-pagebody -->
    </div><!-- sl-mainpanel -->
    <!-- ########## END: MAIN PANEL ########## -->
  <?php include '../footer.php'; ?>
    