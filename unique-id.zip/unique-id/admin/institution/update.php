<?php
  spl_autoload_register(function($class_name){
   include "../../classes/".$class_name.".php";
});

//error_reporting(0);

//update  
$institution = new Institution();

if (isset($_GET['id'])) {
      $id = (int)$_GET['id'];
   
   $std = $institution->getInstitutionById($id);

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update'])) {
     $msg = $institution->updateInstitution($id, $_POST);
}

}
?>

  <?php include '../header.php';?>
  
   <!-- ########## START: MAIN PANEL ########## -->
    <div class="sl-mainpanel"> 
      <div class="sl-pagebody">
        <div class="row row-sm">
          <div class="col-xl-12 mg-xl-t-0">
              <?php
                if (isset($msg)) {
                   echo $msg;
                  }
                ?>

                <?Php 
                  if (isset($_GET['error_msg'])) {
                     $msg =   $_GET['error_msg'];
                     echo $msg;
                   }
                ?>
            <div class="card pd-20 pd-sm-40 form-layout form-layout-5">
              
              <div class="row">
                <div class="col-md-4">
                  <h6 class="tx-gray-800 tx-uppercase tx-bold tx-20 pb-3">Update Instituion</h6>
                </div>
                <div class="col-md-4"></div>
                <div class="col-md-4 view1">
                  <a href="all-institution.php"><i class="fa fa-arrow-left back"> BACK</i></a>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12 tx-center">
                  <!-- <h2 class="tx-gray-1000 tx-uppercase tx-bold tx-20 pb-5">Institution Form</h2 -->
                </div>
              </div>
            
          <form action="" method="POST" enctype="multipart/form-data"> 
           
            <div class="row mb-3">
            <label for="inputEmail3" class="col-sm-3 col-form-label"><h6 class="text-black">শিক্ষা প্রতিষ্ঠানের নাম</h6></label>
            <span><h3 class="text-black">:</h3></span>
            <div class="col-sm-8">
              <input type="text" class="form-control" id="ins_name"   name="ins_name" value="<?php echo $std['ins_name']; ?>">
            </div>
            </div>

             <div class="form-layout-footer mg-t-30 mg-r-65">
              <button type="submit" class="btn btn-info mg-r-5" name="update" style="cursor: pointer;">update</button>
              <button class="btn btn-secondary" style="cursor: pointer;">Cancel</button>
              </div><!-- form-layout-footer -->
           </form>
            </div><!-- card -->
          </div><!-- col-6 -->
        </div><!-- row -->
      </div><!-- sl-pagebody -->
    </div><!-- sl-mainpanel -->
    <!-- ########## END: MAIN PANEL ########## -->

    <script src="../lib/jquery/jquery.js"></script>
    <script src="../lib/popper.js/popper.js"></script>
    <script src="../lib/bootstrap/bootstrap.js"></script>
    <script src="../lib/perfect-scrollbar/js/perfect-scrollbar.jquery.js"></script>
    <script src="../lib/highlightjs/highlight.pack.js"></script>
    <script src="../lib/medium-editor/medium-editor.js"></script>
    <script src="../lib/summernote/summernote-bs4.min.js"></script>
    <script src="../js/starlight.js"></script>
  </body>
</html>
