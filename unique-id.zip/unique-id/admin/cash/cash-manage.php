<?php
  spl_autoload_register(function($class_name){
   include "../../classes/".$class_name.".php";
});

//error_reporting(0);

$admission = new Admission();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
     $msg = $admission->insertStudent($_POST);
}

//Session Start
 Session::init();
  if (! isset($_SESSION['login'])){
  header ('Location:../login.php');
  die();
  }

?>

<?php include '../header.php';?>
  
   <!-- ########## START: MAIN PANEL ########## -->
  <div class="sl-mainpanel"> 
    <div class="sl-pagebody">
    <?php
        if (isset($msg)) {
           echo $msg;
          }
        ?>
        <div class="row row-sm">
          <div class="col-md-12 mg-xl-t-0">
            <div class="card pd-20 pd-sm-40 form-layout form-layout-5"> 
              <div class="row">
                <div class="col-md-12">
                  <h6 class="tx-gray-800 tx-uppercase tx-bold tx-20 pb-5 text-center">Manage Income And Expand</h6>
                </div>
              </div>
          
        <div class="row">
          <div class="col-md-6">
            <h4 class="tx-center bg-primary tx-white p-2">Income</h4>
            <div class="panel">
           <form action="" method="POST" enctype="multipart/form-data"> 
            <div class="row mb-3">
            <label for="inputEmail3" class="col-sm-4 col-form-label"><h6 class="text-black">ছাত্র/ছাত্রীর নাম</h6></label>
            <div class="col-sm-8">
              <input type="text" class="form-control" id="name" name="name" placeholder="">
            </div>
            </div>

             <div class="form-layout-footer mg-t-30 mg-r-75 tx-right">
              <button type="submit" class="btn btn-info mg-r-5" name="submit" style="cursor: pointer;">Submit</button>
              <button class="btn btn-secondary" style="cursor: pointer;">Cancel</button>
              </div><!-- form-layout-footer -->
           </form>
       </div>
      </div>
    
        <div class="col-md-6">
          <h4 class="tx-center bg-primary tx-white p-2">Expense</h4>
          <div class="panel">
         <form action="" method="POST" enctype="multipart/form-data"> 
          <div class="row mb-3">
          <label for="inputEmail3" class="col-sm-4 col-form-label"><h6 class="text-black">ছাত্র/ছাত্রীর নাম</h6></label>
          <div class="col-sm-8">
            <input type="text" class="form-control" id="name" name="name" placeholder="">
          </div>
          </div>

           <div class="form-layout-footer mg-t-30 mg-r-75 tx-right">
            <button type="submit" class="btn btn-info mg-r-5" name="submit" style="cursor: pointer;">Submit</button>
            <button class="btn btn-secondary" style="cursor: pointer;">Cancel</button>
            </div><!-- form-layout-footer -->
          </form>
         </div>
        </div><!-- card -->
      </div><!-- col-6 -->
    </div><!-- row -->
  </div><!-- sl-pagebody -->
</div><!-- sl-mainpanel -->
<!-- ########## END: MAIN PANEL ########## -->
<?php include '../footer.php'; ?>
