$(document).ready(function(){
    $(window).scroll(function(){
        // sticky navbar on scroll script
        if(this.scrollY > 20){
            $('.navbar').addClass("bg-yellowgreen");
        }else{
            $('.navbar').removeClass("bg-yellowgreen");
            
        }

        // sticky nav-link on scroll script
        if(this.scrollY > 20){
            $('.nav-link').addClass("text-white");
        }else{
            $('.nav-link').removeClass("text-white");
            
        }

        // sticky navbar-brand on scroll script
        if(this.scrollY > 20){
            $('.navbar-brand').addClass("text-white");
        }else{
            $('.navbar-brand').removeClass("text-white");
            
        }

    
    });

});