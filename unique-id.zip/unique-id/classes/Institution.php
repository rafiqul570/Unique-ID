<?php
spl_autoload_register(function($class_name){
include "../../classes/".$class_name.".php";
}); 

//error_reporting(0);  

/*
class
*/ 

class Institution{

  private $db;

  public function __construct(){
    $this->db = new Database();
      
   }


//Insert DATA
 public function insertInstitution($data){
    $ins_name = $data['ins_name'];
            
    if ($ins_name == "" ) {
        
      $msg = "<div class='alert  alert-success alert-dismissible fade show' role='alert'>
                  <span class='badge badge-pill badge-success'> Error !</span> Field must not be Empty!
                  <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                      <span aria-hidden='true'>&times;</span>
                  </button>
              </div>";
    
         return $msg; 
   
 } 

   
   $query = "INSERT INTO institution (ins_name) VALUES ('$ins_name');";
    
    $result = $this->db->insert($query);

   if ($result) {

            $msg = '<div class="alert alert-danger alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
             <strong>Success !</strong> Data Inserte Successfully.
            </div>';
  
       return $msg;
     
       
   }else{

        $msg = '<div class="alert alert-danger alert-dismissible">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
         <strong>Error !</strong> Data Not Inserted.
        </div>';
  
       return $msg; 
     }
 
    
    }
  
  public function getAllInstitutionData(){
        $query = "SELECT *FROM institution ORDER BY id DESC";
        $result = $this->db->select($query);
         if($result->num_rows > 0){
            return $result;
          } else {
            return false;
          } 
        }

//Select data in Update page (Admission)
 
    public function getInstitutionById($id){
      
    $sql = "SELECT * FROM institution WHERE id = '$id' LIMIT 1";
             $query = $this->db->select($sql);
             $result = mysqli_fetch_array($query);
             return $result;
     }


//Update Image/Data
   public function updateInstitution($id, $data){
          $sql = "SELECT * FROM institution WHERE id = '$id'";
          $result = $this->db->select($sql);
          $row = mysqli_fetch_array($result);
          
          $ins_name = $data['ins_name'];
      

$query = "UPDATE institution SET ins_name = '$ins_name' WHERE id = '$id' ";
    
       $result = $this->db->update($query);

    if ($result) {
      header("Location: all-institution.php?success_msg=".urlencode('
             <div class="alert alert-danger alert-dismissible">
             <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
              <strong>Success !</strong> Data Update Successfully.
             </div>

        '));
   

  }else{

      header("Location: update.php?error_msg=".urlencode('

            <div class="alert alert-danger alert-dismissible">
             <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
              <strong>Success !</strong> Data Not Update.
             </div>

        '));
  
  
  }
   

  } 


//Delete Admission  
  public function deleteInstitution($id){
         
        $query = "DELETE FROM institution WHERE id = '$id'";
        $result = $this->db->delete($query);   
            
       
        if ($result){
          $msg = '<div class="alert alert-danger alert-dismissible">
              <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
               <strong>Success !</strong> Data Delete Successfully.
              </div>';
      
           return $msg; 
          
     
    }else{

      $msg = '<div class="alert alert-danger alert-dismissible">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                 <strong>Error !</strong> Data Not Deleted.
                </div>';
        
             return $msg; 
    
    }
    
        }


 }

 ?>