<?php
include_once 'Session.php';
?>

<?php
spl_autoload_register(function($class_name){
include "../../classes/".$class_name.".php";
});

error_reporting(0);
 
class User{

private $db;

  public function __construct(){
    $this->db = new Database();
  }


public function userRegistration($data){
		$name = $data['name'];
		$username = $data['username'];
		$phone = $data['phone'];
		$role = $data['role'];
		$password = md5($data['password']);
		

	if ($name == "" || $username == "" || $phone == "" || $role == "" || $password == "") {

            $msg = '<div class="alert alert-success alert-dismissible">
             <strong>Error !</strong> Field must not be Empty.
                    
            </div>';
			
		       return $msg; 
		 
	 } 

	 if (strlen($username ) < 3) {
	 	   
			$msg = "<div class='alert  alert-success alert-dismissible fade show' role='alert'>
                    <span class='badge badge-pill badge-success'> Error !</span> Username is too short.
                </div>";
			
		    return $msg;	

	}elseif(preg_match('/[^a-z0-9_-]+/i', $username)) {
			
	       $msg = '<div class="alert alert-danger alert-dismissible">
             <strong></strong> The Username must only contain alphanumerically, deshes and underscores !
            </div>'; 

	        return $msg;
	}

	$query = "SELECT * FROM user WHERE username = '$username' LIMIT 1";
	$chk_username = $this->db->select($query);

	if ($chk_username !== false) {

		$msg = '<div class="alert alert-danger alert-dismissible">
             <strong></strong> The Username already Exist!
            </div>';

        return $msg;
			
	}else{
	

   $conn = mysqli_connect('localhost','root','','msam');
   $sql = "INSERT INTO user (name,username,phone,password,role) VALUES ('$name', '$username', '$phone', '$password','$role')";
       $result = mysqli_query($conn, $sql);
       if ($result) {
        $last_id = mysqli_insert_id($conn);
       	if($last_id){
       		$code = rand(20,9999);
       		$user_id =" MM".$code.$last_id;
       		$unpass =" MS".$code."AM";
       		$query = "UPDATE user SET user_id = '$user_id', unpass = '$unpass' WHERE id = '$last_id' ";
       		$res =mysqli_query($conn, $query);
       	}
		
	
			
		  $msg = '<div class="alert alert-danger alert-dismissible">
             <strong> Success !</strong> Registration Successfully ! Please Login.
            </div>';
			
		    return $msg;
	   
		   
	}else{

     		$msg = '<div class="alert alert-danger alert-dismissible">
             <strong>Error !</strong> Data Not Inserte.
            </div>';
			
		    return $msg;  
	 
	
	   }
	
    } 
 
}

 //====== LOGIN ADMIN START ===============//

 public function adminLogin($data){
	    
		$email = $data['email'];
		$password = md5($data['password']);
		
	   if ($email == "" || $password == "") {	
    	
			$msg = '<div class="alert alert-success alert-dismissible">
             <strong>Error !</strong> Field must not be Empty.
                    
            </div>';
			
		     return $msg;   
	 

		}   
   		

	$query = "SELECT * FROM admin WHERE email = '$email' AND password = '$password' LIMIT 1";
		$result = $this->db->select($query);
         if($result->num_rows > 0){
            $value = $result->fetch_assoc();
            Session::init();
		  	Session::set("login", true);
		  	Session::set("id", $value['id']);
		  	Session::set("name", $value['name']);
		  	Session::set("username", $value['username']);
		  	Session::set("role", $value['role']);
          	
          	if($_SESSION['role'] == 1){
          	 
          	  header("Location: index.php?success_msg=".urlencode('
	             <div class="alert alert-danger alert-dismissible">
	             <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
	              <strong>Success !</strong> You are logedin.
	             </div> '));	
          	}
          	
          	if($_SESSION['role'] == 0){
          	  header("Location: login.php?error_msg=".urlencode('
	             <div class="alert alert-danger alert-dismissible">
	              <strong>Error !</strong> The Email address is not valid ! Please Try Again.
	             </div> '));	
	          	}
         

          }else{
          	header("Location: login.php?error_msg=".urlencode('
	             <div class="alert alert-danger alert-dismissible">
	             <strong></strong> The Email Address is not valid ! Please Try Again.
	              </div> '));	
          }		
     
	}
 
 //====== LOGIN USER START ===============//
    public function userLogin($data){
		$username = $data['username'];
		$password = md5($data['password']);
		
	   if ($username == "" || $password == "") {	
    	
		      $msg = '<div class="alert alert-success alert-dismissible">
             <strong>Error !</strong> Field must not be Empty.
                    
            </div>';
			
		     return $msg;  
	 
		 }  
   		

	$query = "SELECT * FROM user WHERE username = '$username' AND password = '$password' LIMIT 1";
		$result = $this->db->select($query);
         
         if($result->num_rows > 0){
            $value = $result->fetch_assoc();
          	
          	Session::init();
		  	Session::set("login", true);
		  	Session::set("id", $value['id']);
		  	Session::set("name", $value['name']);
		  	Session::set("username", $value['username']);
		  	Session::set("role", $value['role']);
          	
           if($_SESSION['role'] == 0){
          	 
          	  header("Location: ../admin/index.php?success_msg=".urlencode('
	             <div class="alert alert-danger alert-dismissible">
	             <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
	              <strong>Success !</strong> You are logedin.
	             </div> '));	
          	}
          	
          	if($_SESSION['role'] == 1){
          	  header("Location: login.php?error_msg=".urlencode('
	             <div class="alert alert-danger alert-dismissible">
	              <strong></strong> The Username is not valid ! Please Try Again.
	             </div> '));	
	          	}
          

          }else{
          	header("Location: login.php?error_msg=".urlencode('
	             <div class="alert alert-danger alert-dismissible">
	             <strong></strong> The Username is not valid ! Please Try Again.
	              </div> '));	
          }
 
   }

//SELECT USER
	public function getAllUserData(){

		$query = "SELECT * FROM user ORDER BY id DESC";
		$result = $this->db->select($query);
		return $result;

 }


}

?>
