<?php
spl_autoload_register(function($class_name){
include "../../classes/".$class_name.".php";
});

//error_reporting(0);

class Notice{

	private $db;

	public function __construct(){
		$this->db = new Database();
		
    }
    
    //Insert Notice
 public function insertNotice($data){
  	     $date    = $data['date'];
		 $subject = $data['subject'];
		
		 $file_name = $_FILES['file']['name'];
		 $file_size = $_FILES['file']['size'];
		 $file_type = $_FILES['file']['type'];
		 $tmp_name  = $_FILES['file']['tmp_name'];
		 $permited  = array('pdf');
		 $div = explode(".", $file_name);
	 	 $file_ext = strtolower(end($div));
	 	 $file_check = in_array($file_ext, $permited);
	 	 $file = uniqid().$file_ext;
		 $uploaded_file = '../uploads/file/'.$file;
		 
		 

      

      if ($date == "" || $subject == "" || $file == "") {
		    	
    	$msg = '<div class="alert alert-danger alert-dismissible">
		        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		         <strong>Error !</strong> Field must not be Empty !
		        </div>';
		
	       return $msg; 
		 
	 }

	 if (empty($file_name)) {
	 	$msg = '<div class="alert alert-danger alert-dismissible">
	 	        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		         <strong>Please !</strong> Select any File .
	 	        </div>';
		
	        return $msg; 
	
		 
	 }elseif($file_size > 304803456){

	 	$msg = '<div class="alert alert-danger alert-dismissible">
	 	        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		         <strong>Error !</strong> Image size should be less then 3KB
	 	        </div>';
		
	        return $msg; 

	 }elseif($file_check === false) {
	 	
	 			
				$msg = '<div class="alert alert-danger alert-dismissible">
	  	        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		         <strong>Sorry !</strong>You can upload only  - pdf		        </div>';
	
	    return $msg;  
	  
	  }else{
 		
	 move_uploaded_file($tmp_name,  $uploaded_file);

	 $query="INSERT INTO notice(date,subject,file) VALUES('$date', '$subject', '$file')";
		$result = $this->db->insert($query);

	if ($result) {
			
	    $msg = '<div class="alert alert-danger alert-dismissible">
		        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		         <strong>Success !</strong>  Data Inserted Successfully.
		        </div>';

        return $msg;
		   
	}else{

 		$msg = '<div class="alert alert-danger alert-dismissible">
		        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		         <strong>Error !</strong>  Sorry, Data Not Inserted.
		        </div>';
		
	     return $msg;  
	
	}
   
   }	

  } 
// Select Notice
  public function getAllNoticeData(){

		$query = "SELECT * FROM notice ORDER BY id DESC";
		$result = $this->db->select($query);
		return $result;

 }

//Update Notice
 
  public function getNoticeById($id){
 	$sql = "SELECT * FROM notice WHERE id = :id LIMIT 1";
 	$query = $this->db->pdo->prepare($sql);
 	$query->bindValue(':id', $id);
	$query->execute();
	$result = $query->fetch(PDO::FETCH_OBJ);
	return $result;
 }

   public function updateNotice($id, $data){

	 	$date = $data['date'];
		$subject = $data['subject'];
	

	$sql = "UPDATE uploads set date = :date, subject = :subject 
	 WHERE id = :id";

			$query = $this->db->pdo->prepare($sql);
			$query->bindValue(':date', $date);
			$query->bindValue(':subject', $subject);
			$query->bindValue(':id', $id);
			$result = $query->execute();

			if ($result) {
		
			    $msg = '<div class="alert alert-danger alert-dismissible">
			        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			         <strong>Error !</strong> Data Updated Successfully.
			        </div>';
			
		       return $msg; 
	   
	
	}else{

		$msg = '<div class="alert alert-danger alert-dismissible">
			        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			         <strong>Error !</strong> Data Not Updated.
			        </div>';
			
		       return $msg; 
	
	}
	

  } 
   
//Delete Notice  
	public function deleteNotice($id){

			$img = "SELECT * FROM uploads WHERE id = $id";
            $q = $this->db->pdo->prepare($img);
            $q->execute();
            $row = $q->fetch();

            $sql = "DELETE FROM uploads WHERE id = :id";
            $query = $this->db->pdo->prepare($sql);
            $query->bindParam(':id', $id, PDO::PARAM_INT);
            $result = $query->execute();   
            $file = $row['file'];
            unlink("../uploads/file/".$file);
           

        if ($result){
        	$msg = '<div class="alert alert-danger alert-dismissible">
			        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			         <strong>Success !</strong> Data Delete Successfully.
			        </div>';
			
		       return $msg; 
		      
	   
		}else{

			$msg = '<div class="alert alert-danger alert-dismissible">
				        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
				         <strong>Error !</strong> Data Not Deleted.
				        </div>';
				
			       return $msg; 
		
	}
	
    }

  }

?>