<?php
spl_autoload_register(function($class_name){
include "classes/".$class_name.".php";
});

//error_reporting(0);  
$notice = new Notice();
?>
<?php 
$breakingNews = $notice->getAllNoticeData();
$allNotice = $notice->getAllNoticeData();
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <title>School Management System</title>
  </head>
  <body>
       <nav class="navbar navbar-expand-lg navbar-light fixed-top">
        <div class="container-fluid px-5 py-3">
        <a class="navbar-brand fs-3" href="#">MSAM</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
          <ul class="navbar-nav m-auto">
            <li class="nav-item">
              <a class="nav-link text-dark fs-6" href="#">Admission</a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-dark fs-6" href="#">Office</a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-dark fs-6" href="#">Result</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle text-dark" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                Acadamic
              </a>
              <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                <li><a class="dropdown-item" href="#">Examination</a></li>
                <li><a class="dropdown-item" href="#">Registration</a></li>
                <li><a class="dropdown-item" href="#">Form Fill-up</a></li>
              </ul>
            </li>
          </ul>
        </div>
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link text-dark fs-6" href="public/login.php">Login</a>
          </li>
        </ul>
      </div>
    </nav>
  
 <!--   Carousel -->
 <div class="container-fluid px-5">
     <div class="row mt-5 pt-5">
          <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel" data-bs-touch="true">
          <div class="caro-img carousel-inner">
            <div class=" carousel-item active">
              <img src="public/images/b3.jpg" class="images wh" alt="...">
            </div>
            <div class="carousel-item">
              <img src="public/images/b8.jpg" class="images wh" alt="...">
            </div>
            <div class="carousel-item">
              <img src="public/images/12.jpg" class="images wh" alt="...">
            </div>
          </div>
          <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
          </button>
          <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
          </button>
        </div>    
        </div>
    </div>

 <!-- breaking-news -->
 <div class="container-fluid px-5 mb-2">
  <div class="row pt-2">
    <div class="breaking-news">
      <marquee onmouseover="this.stop()" onmouseout="this.start()">
       <?php while($row = mysqli_fetch_assoc($breakingNews)) { ?>
         <img src="public/images/1.jpg" width="20px" alt="">
          <?php echo $row['subject']; ?>
         <?php } ?>
      </marquee>  
    </div>
  </div>
</div>

<!-- Galary Section -->
<div class="container-fluid px-5">
  <div class="row py-5">
    <div class="col-md-3">
      <table class="table table-bordered">
  <thead>
    <tr class="bg-gold text-white fs-5">
      <th class="text-center">QUICK LINKS</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td></td>
    </tr>
    <tr>
      <td></td>
    </tr>
    <tr>
      <td></td>
    </tr>
    <tr>
      <td></td>
    </tr>
  </tbody>
</table>
    </div>
    <div class="col-md-6">
      <h2 class="color-gold">Welcomw to Moghia Salehia Alim Madrasha</h2>
      <P>Lorem ipsum dolor sit amet consectetur adipisicing elit. Perferendis accusantium temporibus vero doloremque recusandae ex molestiae neque nisi, sequi similique amet repellat. Accusamus unde in laudantium distinctio vel nisi, labore.</P>

      <P>Lorem ipsum dolor sit amet consectetur adipisicing elit. Perferendis accusantium temporibus vero doloremque recusandae ex molestiae neque nisi, sequi similique amet repellat. Accusamus unde in laudantium distinctio vel nisi, labore.</P>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Perferendis accusantium .</P>

    </div>
    <div class="col-md-3">
      <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
     <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="public/images/b6.jpg" class="images wh2" alt="...">
        <div class="carousel-caption d-none d-md-block">
      </div>
      <h5 class="text-center"><a class="aa" href="#">First slide label</a></h5>
      </div>
      <div class="carousel-item">
        <img src="public/images/1.jpg" class="images wh2" alt="...">
        <h5 class="text-center"><a class="aa" href="#">Second slide label</a></h5>
      </div>
      <div class="carousel-item">
        <img src="public/images/3.jpg" class="images wh2" alt="...">
        <h5 class="text-center"><a class="aa" href="#">Third slide label</a></h5>
      </div>
  </div>
</div>
    </div>
  </div>
</div>

<!-- Notice section -->
<div class="container-fluid px-5 mb-2">
 <div class="row">
  <div class="col-md-12">
    
  </div>
  <div class="col-md-3">
    <table class="table table-bordered">
  <thead>
    <tr class="bg-gold text-white fs-5">
      <th class="text-center">WODNLOAD LINKS</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td></td>
    </tr>
    <tr>
      <td></td>
    </tr>
    <tr>
      <td></td>
    </tr>
    <tr>
      <td></td>
    </tr>
  </tbody>
</table>
  </div>
  <div class="col-md-9 notice-table">
    <table class="table table-bordered ">
  <thead>
    <tr align="center" class="bg-gold text-white fs-5">
      <th width="75%">Notice</th>
      <th width="25%">Publish Date</th>
    </tr>
  </thead>
<?php while($row = mysqli_fetch_assoc($allNotice)) { ?>
  <tbody>
    <tr>
      <td><a class="a" href="admin/uploads/file/<?php echo $row['file']; ?>" target="_ blank"><?php echo $row['subject'];?></a></td>
      <td align="center"><?php echo $row['date'];?></td>
    </tr>
  </tbody>
  <?php } ?>
</table>
  </div>
  </div>
</div>

<!-- footer section start -->
  <div class="footer">
    <div class="row pt-3">
      <span>Created By RIBD | <span class="far fa-copyright"></span> 2022 All rights reserved.</span>
    </div>
  </div>
    <!-- JS -->
    <script src="public/js/jquery.js"></script>
    <script src="public/js/bootstrap.js"></script>
    <script src="public/js/main.js"></script>

</body>
</html>
